This firmware is directly compatible with Intel platforms.
AMD users please use the front panel USB 3.0 ports or a PCIe USB 3.0 expansion card!

1. Ensure your Tasoller is running Touch Firmware 2.0 or above
    If your Tasoller is still running 1.0 please first upgrade to 2.0 using an UART cable!
    Please follow the instructions on the official DJ DAO support site: https://www.dj-dao.com/en/11.html

2. Follow the instructions in the word/pdf file